/*global
    require*/
"use strict";


//See README.md
var http = require('http'),
    express = require('express'),
    anyDB = require('any-db'),
    bodyParser = require('body-parser'),
    engines = require('consolidate'),

    // Chatroom DB
    conn = anyDB.createConnection('sqlite3://chatroom.db'),

    // App and server
    app = express(),
    server = http.createServer(app),

    // Add socket.io
    io = require('socket.io').listen(server),

    /**
     * Generates a room name (not necessarily a new one)
     * @returns {string} the room name
     */
    generateRoomIdentifier = function () {
        // make a list of legal characters
        // we're intentionally excluding 0, O, I, and 1 for readability
        var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789',
            result = '',
            i;

        for (i = 0; i < 6; i += 1) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }

        return result;
    },

    users = {},
    userIdCounter = 0,

    generateNickname = function (name, socket) {

        if (!name) {
            socket.emit('badName', name);
            return "Anonymous";
        } else {
            name = name.replace(/ /g, "");
        }

        if (name.length > 16) {
            return "ReallyLongName";
        }

        return name;
    },


    namespace = '/';


// App requirements
app.use(express.static('public'));
app.use(bodyParser.urlencoded());
app.engine('html', engines.hogan); // tell Express to run .html files through Hogan
app.set('views', __dirname + '/view'); // tell Express where to find templates

// Sockets

io.sockets.on('connection', function (socket) {
    // clients emit this when they join new rooms
    socket.on('join', function (roomName, nickname, callback) {

        if (users[roomName] === undefined) {
            users[roomName] = {};
        }

        nickname = generateNickname(nickname, socket);

        socket.join(roomName); // this is a socket.io method   
        socket.roomName = roomName;
        socket.userId = userIdCounter;
        socket.nickname = nickname; // yay JavaScript! see below

        users[roomName][socket.userId] = nickname;
        userIdCounter += 1;

        socket.emit('nickname', socket.nickname);


        // get a list of messages currently in the room, then send it back
        conn.query('SELECT * FROM messages where room=$1 ORDER BY time ASC;', [roomName],
            function (err, data) {
                callback(data.rows);
                io.sockets.in(socket.roomName).emit('userList', users[socket.roomName]);
                io.sockets.in(roomName).emit('newMember', nickname, roomName);
            });

    });

    // this gets emitted if a user changes their nickname
    socket.on('nickname', function (nickname) {
        var oldName = socket.nickname;
        socket.nickname = generateNickname(nickname, socket);
        if (socket.nickname !== oldName && socket.roomName !== undefined) {
            users[socket.roomName][socket.userId] = socket.nickname;
            socket.emit('nickname', socket.nickname);
            io.sockets.in(socket.roomName).emit('userList', users[socket.roomName]);
            io.sockets.in(socket.roomName).emit('membershipChanged', oldName, socket.nickname, socket.roomName);
        }
    });

    socket.on('typing', function () {
        io.sockets.in(socket.roomName).emit('typing', socket.nickname);
    });

    socket.on('whisper', function (nickname, message) {
        var time = Math.floor(new Date() / 1000),
            response = {
                'time': time,
                'nickname': socket.nickname,
                'to': nickname,
                'body': message,
                'type': 'whisper'
            },
            userList = io.sockets.in(socket.roomName).sockets,
            user;

        if (message !== "") {
            for (var index in userList) {
                user = userList[index];
                if (user.nickname === nickname) {
                    user.emit('message', response);
                } else if (user.userId === socket.userId) {
                    socket.emit('message', response);
                }
            }
        }
    });

    // the client emits this when they want to send a message
    socket.on('message', function (message) {
        var time = Math.floor(new Date() / 1000),
            response = {
                'time': time,
                'nickname': socket.nickname,
                'body': message
            };

        if (message !== "" && socket.roomName) {
            // process an incoming message (don't forget to broadcast it to everyone!)
            io.sockets.in(socket.roomName).emit('message', response);

            conn.query('INSERT INTO messages(room, nickname, body, time) VALUES($1, $2, $3, $4)', [socket.roomName, socket.nickname, message, time]);
        }
    });

    // the client disconnected/closed their browser window
    socket.on('disconnect', function () {
        // Leave the room!

        try {
            delete users[socket.roomName][socket.userId];
        } catch (e) {}

        io.sockets.in(socket.roomName).emit('userList', users[socket.roomName]);
        io.sockets.in(socket.roomName).emit('leave', socket.nickname, socket.roomName);
    });
});


// Get & Post requests

app.get('/favicon.ico', function (request, response) {
    response.end();
});

app.get('/', function (request, response) {
    var name = request.params.roomName; // 'ABC123'
    response.render('index.html', {
        roomName: name
    });
});

app.get('/recentrooms', function (request, response) {
    conn.query("SELECT DISTINCT room FROM messages WHERE time >= strftime('%s','now') - 300 ORDER BY time DESC;",
        function (err, data) {
            response.json({
                rooms: data.rows,
                users: users
            });
            response.end();
        });
});


app.get('/generate', function (request, response) {
    var getNew = function () {
        var id = generateRoomIdentifier();
        conn.query('SELECT * FROM messages where room=$1', [id],
            function (err, data) {
                if (data.rows.length === 0) {
                    console.log("Created room: " + id);
                    response.render('redirect.html', {
                        roomName: id
                    });
                } else {
                    getNew();
                }
            });
    };
    getNew();
});


app.get('/:roomName', function (request, response) {
    var name = request.params.roomName; // 'ABC123'
    if (name.length === 6) {
        response.render('chatroom.html', {
            roomName: name
        });
    } else {
        response.render('index.html', {
            roomName: name
        });
    }
});


//Visit localhost:8080
server.listen(8080);