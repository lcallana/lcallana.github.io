/*global
    require, console*/
"use strict";

var anyDB = require('any-db'),
    conn = anyDB.createConnection('sqlite3://chatroom.db');

conn.query('CREATE TABLE messages ( id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT, nickname TEXT, body TEXT, time INTEGER);')
    .on('end', function () {
        console.log('Made table!');
    });