/*global
    $, console, io, prompt*/

var socket = io.connect(),
    displayName;


$(function () {
    'use strict';

    if (!window.localStorage.getItem('name')) {
        displayName = prompt('What do you want your nickname to be?', 'Anonymous')
    } else {
        displayName = window.localStorage.getItem('name');
    }



    // Variables
    var

    // Various Attributes
        joinDone = false,
        prevUser,
        typingUserIntervals = {},
        typingDoneInterval,
        typingUserList = {},
        isTyping = false,

        // Web elements
        displayNameInput = $('#displayName'),
        messageBoard = $('#messages'),
        messageInput = $('#chat input'),
        onlineUserList = $('#userList'),
        sendButton = $('#chat button'),
        settingsGear = $('.settings-button'),
        settingsMenu = $('#settings'),
        settingsDone = settingsMenu.find('button'),
        typingAlert = $('#typing'),
        home = $('#home'),


        // Proper youtube urls
        youtube = 'https://www.youtube.com',
        youtube2 = 'https://youtu.be',
        youtube3 = 'https://m.youtube.com',

        // All other variables here are functions (except room name)

        /**
         * Gets a meta tag
         * @param   {string} name the name of the dat
         * @returns {object} the tag data
         */
        meta = function (name) {
            return $('meta[name=' + name + ']').attr('content');
        },

        room = meta('roomName'), // Room name

        /**
         * Checks if the message board can be autoscrolled
         * @returns {boolean} true if it can, false otherwise
         */
        checkAutoScroll = function () {
            return messageBoard.scrollTop() >= messageBoard.prop('scrollHeight') - messageBoard.height() - 100;
        },

        isNearBottom = function () {
            return messageBoard.scrollTop() >= messageBoard.prop('scrollHeight') - messageBoard.height() - 32;
        },


        /**
         * Autoscrolls the message board
         */
        autoScroll = function () {
            if (joinDone) {
                messageBoard.stop();
                messageBoard.animate({
                    scrollTop: messageBoard.prop('scrollHeight')
                }, 800);
            } else {
                messageBoard.scrollTop(messageBoard.prop('scrollHeight'));
            }
        },

        isYoutubeVideo = function (message) {
            var text = message.replace("http://", "https://");
            return (text.substring(0, youtube.length) === youtube || text.substring(0, youtube2.length) === youtube2 || text.substring(0, youtube3.length) === youtube3) && text !== youtube && text !== youtube2;
        },

        /**
         * Renders a given message.
         * @param   {object}   message the message to render
         */
        renderMessage = function (message) {
            if (message.nickname === '') {
                message.nickname = 'Anonymous';
            }

            var isUser = message.nickname === displayName && message.type !== 'server',

                line = $(document.createElement('li'))
                .addClass('message-line user-' + (isUser)),

                container = $(document.createElement('div'))
                .addClass('message'),

                // The nickname
                caret = $(document.createElement('div'))
                .addClass('caret'),

                // The nickname
                nickname = $(document.createElement('span'))
                .addClass('nickname')
                .text(message.nickname),

                // The message body
                body = $(document.createElement('p'))
                .addClass('body')
                .text(message.body),

                prevMessage = messageBoard.find('.message-line').last(),

                scroll = checkAutoScroll(),

                endString = message.body.substring(message.body.length - 4, message.body.length),


                video,

                videoWrapper,

                image,

                whisperText;


            if (message.type !== undefined) {
                line.addClass(message.type);
            }

            // Server messages
            if (message.type === 'server') {
                body.addClass(message.action);
            }

            // Whispers
            if (message.type === 'whisper') {
                if (isUser) {
                    whisperText = 'Whispers to ' + message.to + ':';
                } else {
                    whisperText = 'Whispers to you: ';
                }

                body.addClass(message.type);
                body.prepend(
                    $(document.createElement('span'))
                    .addClass('whisper-pre')
                    .text(whisperText)
                );
            }

            // Check if same user as before
            if (prevUser === message.nickname) {
                prevMessage.find('.caret').before(body);
            } else {
                line
                    .append(nickname)
                    .append(body);

                line
                    .append(caret);

                typingAlert.before(line);
            }

            // Check for youtube video
            if (isYoutubeVideo(message.body)) {
                message.body =
                    message.body
                    .replace("http://", "https://")
                    .replace('https://m.', 'https://www.')
                    .replace('youtu.be', 'www.youtube.com/embed')
                    .replace('watch?v=', 'embed/')
                    .replace('youtube.com', 'youtube-nocookie.com');

                if (message.body.indexOf('?') !== -1) {
                    message.body = message.body.substring(0, message.body.indexOf('?'));
                }

                if (message.body.indexOf('&') !== -1) {
                    message.body = message.body.substring(0, message.body.indexOf('&'));
                }


                video = $(document.createElement('iframe'))
                    .attr({
                        'frameborder': 0,
                        'src': message.body,
                        'width': '1280px',
                        'height': '720px',
                        'scrolling': 'no'
                    });

                videoWrapper = $(document.createElement('div')).addClass('video-wrapper').append(video);

                body
                    .contents().filter(function () {
                        return this.nodeType === 3;
                    }).remove();
                body
                    .append(videoWrapper)
                    .addClass('video');
                if (scroll) {
                    autoScroll();
                }

                video.on('load', function () {

                });
            }

            // Check for images
            if (endString === '.png' || endString === '.jpg' || endString === '.gif') {
                image = $(document.createElement('img'))
                    .attr('src', message.body);
                image
                    .load(function () {
                        body
                            .contents().filter(function () {
                                return this.nodeType === 3;
                            }).remove();
                        body
                            .append(image)
                            .addClass('img');
                        if (scroll) {
                            autoScroll();
                        }

                    })
                    .error(function () {});
            }


            prevUser = message.nickname;
        },

        /**
         * Updates the message board.
         * @param {object} response the messages in the response list
         */
        updateMessageBoard = function (response) {
            var canAutoScroll = checkAutoScroll();
            $.each(response, function (index, message) {
                renderMessage(message, false);
            });

            if (canAutoScroll) {
                autoScroll();
            }
        },

        cancelScroll = function (e) {
            //if (e.originalEvent.wheelDelta > 0 || e.detail < 0) {
            messageBoard.stop();
        },

        /**
         * Sends a message
         * @param {string} message the message to send to the backend
         */
        sendMessage = function (body) {
            var user,
                index;
            if (body.substring(0, 1) === '@') {
                index = body.indexOf(' ');
                if (index > -1) {
                    user = body.substring(1, index);
                    body = body.substring(index + 1);
                    socket.emit('whisper', user, body);
                }
            } else {
                socket.emit('message', body);
            }
            messageInput.val('');
        };


    // Display name setting
    if (displayName === null || displayName === undefined) {
        displayName = 'Anonymous';
    }


    /* ===============================================
    ================= JQuery Events ==================
    ==================================================*/

    home.click(function (e) {
        e.preventDefault();
        window.localStorage.setItem('room', 'none');
        window.location = '/';
    });

    // Send the message when the user presses the Enter key
    messageInput.on('keypress', function (e) {
        if (e.charCode === 13 || e.keyCode === 13) {
            sendMessage($(this).val());
            $(this).blur();
        } else {
            socket.emit('typing');
        }
    });

    // Focus on the message input if user starts typing
    $('body').on('keydown', function (e) {
        if (!e.ctrlKey && document.activeElement === document.body) {
            if (settingsMenu.hasClass('open')) {
                displayNameInput.focus();
            } else {
                messageInput.focus();
            }
        }
    });

    // Send the message in the message input on click
    sendButton.click(function () {
        sendMessage(messageInput.val());
    });

    // Cancel scrolling animation on user interrupt
    messageBoard.bind('DOMMouseScroll mousewheel', cancelScroll);

    document.addEventListener('touchmove', cancelScroll, false);

    // Open/Close Settings menu
    sendButton.click(function () {
        sendMessage(messageInput.val());
    });

    /* ===============================================
    ================ Settings Events =================
    ==================================================*/

    settingsGear.click(function () {
        if (settingsMenu.hasClass('open')) {
            settingsMenu.removeClass('open');
            settingsGear.removeClass('open');
        } else {
            settingsMenu.addClass('open');
            settingsGear.addClass('open');
        }
    });


    settingsDone.click(function () {
        settingsMenu.removeClass('open');
        settingsGear.removeClass('open');
        // join the room
        if (displayNameInput.val()) {
            socket.emit('nickname', displayNameInput.val(), function (messages) {
                updateMessageBoard(messages);
            });
        }
    });


    displayNameInput.keypress(function (e) {
        if (e.charCode === 13 || e.keyCode === 13) {
            if (displayNameInput.val()) {
                socket.emit('nickname', displayNameInput.val(), function (messages) {
                    updateMessageBoard(messages);
                });
            }
            $(this).blur();
            settingsMenu.removeClass('open');
            settingsGear.removeClass('open');

        }
    });

    // Leave message input on Esc key
    $(document).keydown(function (e) {
        if (e.keyCode === 27) {
            messageInput.blur();
            if (settingsMenu.hasClass('open')) {
                displayNameInput.blur();
                settingsMenu.removeClass('open');
                settingsGear.removeClass('open');
            } else {
                settingsMenu.addClass('open');
                settingsGear.addClass('open');
            }
        }
    });


    /* ===============================================
    ==================== Sockets =====================
    ==================================================*/


    // join the room
    socket.emit('join', room, displayName, function (messages) {
        updateMessageBoard(messages);
        joinDone = true;
    });

    // handle room membership changes
    socket.on('leave', function (member, serverName) {
        var scroll = checkAutoScroll();
        renderMessage({
            'nickname': '@' + serverName,
            'body': member + ' has disconnected',
            'type': 'server',
            'action': 'leave'
        });
        if (scroll) {
            autoScroll();
        }
    });

    // handle incoming messages
    socket.on('typing', function (member) {

        clearInterval(typingUserIntervals[member]);
        clearInterval(typingDoneInterval);

        typingUserList[member] = true;
        isTyping = true;


        var numUsersTyping = Object.keys(typingUserList).length;

        if (numUsersTyping > 1) {
            typingAlert.find('span.user').text(numUsersTyping);
            typingAlert.find('span.flavor').text(' users are typing');
        } else {
            typingAlert.find('span.user').text(member);
            typingAlert.find('span.flavor').text(' is typing');
        }


        typingAlert.addClass('alert');

        typingUserIntervals[member] = setInterval(function () {
            delete typingUserList[member];
            clearInterval(typingUserIntervals[member]);
        }, 2000);

        typingDoneInterval = setInterval(function () {
            typingAlert.removeClass('alert');
            isTyping = false;
            clearInterval(typingDoneInterval);
        }, 2000);
    });

    // handle incoming messages
    socket.on('message', function (message) {
        typingAlert.removeClass('alert');
        updateMessageBoard([message]);
    });

    // handle room membership changes
    socket.on('membershipChanged', function (oldMember, newMember, serverName) {
        var scroll = checkAutoScroll();
        renderMessage({
            'nickname': '@' + serverName,
            'body': oldMember + '\'s nickname is now ' + newMember,
            'type': 'server',
            'action': 'name'
        });
        if (scroll) {
            autoScroll();
        }
    });

    // handle nickname change
    socket.on('nickname', function (nickname) {
        displayName = nickname;


        var date = new Date();

        // Get unix milliseconds at current time plus number of days
        date.setTime(+date + (99999999)); //24 * 60 * 60 * 1000
        window.localStorage.setItem('name', nickname);
        window.localStorage.setItem('room', room);


        //alert(nickname + ' ' + window.localStorage);


        messageInput.attr('placeholder', 'Chatting as ' + displayName);
        displayNameInput.attr('placeholder', displayName);
        displayNameInput.val('');
    });

    // handle incoming messages
    socket.on('newMember', function (nickname, serverName) {
        var scroll = checkAutoScroll();
        renderMessage({
            'nickname': '@' + serverName,
            'body': nickname + ' has joined the chatroom',
            'type': 'server',
            'action': 'join'
        });
        if (scroll) {
            autoScroll();
        }
    });

    // handle user list initiation
    socket.on('userList', function (users) {
        var list = [];
        $.each(users, function (index, value) {
            list.push(value);
        });
        list.sort();
        onlineUserList.empty();
        $.each(list, function (index, value) {
            var li = $(document.createElement('li')).text(value);
            onlineUserList.append(li);
        });
    });


    // iPhone Support, thanks to http://stackoverflow.com/questions/10238084
    $(document).on('touchmove', function (e) {
        e.preventDefault();
    });

    $('body').on('touchmove', function (e) {
        e.preventDefault();
    });

    $('#messages, #settings').bind('touchmove', function (e) {
        e.stopPropagation();
    });

});