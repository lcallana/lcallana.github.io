/*global
    $, console*/

$(function () {
    "use strict";
    var roomElement = $('#rooms ul');

    $.get('/recentrooms', function (res) {
        $.each(res.rooms, function (index, value) {
            var listElement = $(document.createElement('li')),
                link = $(document.createElement('a')),
                activeUsers = $(document.createElement('ul')),
                userList = [];

            link
                .text(value.room)
                .attr({
                    'href': '/' + value.room
                })
                .append(activeUsers);

            $.each(res.users[value.room], function (index, value) {
                userList.push(value);
            })
            userList.sort();

            $.each(userList, function (index, value) {
                var user = $(document.createElement('li'))
                    .text(value);
                activeUsers.append(user);
            });

            listElement
                .append(link);

            roomElement.append(listElement);
        });

        $(function () {
            $("a").click('click', function (event) {
                event.preventDefault();
                window.location = this.href;
            });
        });


    });



    // Courtesy of http://stackoverflow.com/questions/2898740
});