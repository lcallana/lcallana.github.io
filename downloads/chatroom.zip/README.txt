Liam Callanan | Chatroom 


Instructions:

- Make sure you've installed npm
- Open a terminal, run npm install in this folder
- run node loader.js (if you haven't run the app before)
- run node server.js
- open up localhost on port 8080